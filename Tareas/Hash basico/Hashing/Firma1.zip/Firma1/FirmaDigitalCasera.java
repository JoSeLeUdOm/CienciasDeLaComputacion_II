import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

public class FirmaDigitalCasera {

    // Grupo de trabajo: primo seguro p (RFC 3526, grupo MODP de 1536 bits),
    // q = (p-1)/2 es el orden del subgrupo, g = 2 es el generador.
    static final BigInteger P = new BigInteger(
        "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD" +
        "129024E088A67CC74020BBEA63B139B22514A08798E3404" +
        "DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C" +
        "245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406" +
        "B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE" +
        "45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD" +
        "24CF5F83655D23DCA3AD961C62F356208552BB9ED529077" +
        "096966D670C354E4ABC9804F1746C08CA237327FFFFFFFF" +
        "FFFFFFFF", 16);
    static final BigInteger Q = P.subtract(BigInteger.ONE).divide(BigInteger.TWO);
    static final BigInteger G = BigInteger.valueOf(2);

    static final String ARCHIVO_CLAVE_PRIVADA = "clave_privada_casera.key";
    static final String ARCHIVO_CLAVE_PUBLICA = "clave_publica_casera.key";

    static final SecureRandom RND = new SecureRandom();

    public static void main(String[] args) throws Exception {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Ingrese el mensaje: ");
        String mensaje = teclado.nextLine();

        BigInteger x = obtenerClavePrivada(); // privada
        BigInteger y = obtenerClavePublica(x); // pública = g^x mod p

        System.out.println("Mensaje original: " + mensaje);

        BigInteger[] firma = firmarMensaje(mensaje, x);
        BigInteger e = firma[0];
        BigInteger s = firma[1];

        System.out.println("Firma generada -> e: " + e);
        System.out.println("Firma generada -> s: " + s);

        System.out.println("\nDATOS QUE RECIBIRIA EL RECEPTOR");
        System.out.println("Mensaje: " + mensaje);
        System.out.println("Firma (e, s): (" + e + ", " + s + ")");
        System.out.println("Clave pública y: " + y);

        boolean esValida = verificarFirma(mensaje, G, s, y);
        System.out.println("Resultado de la verificación: " +
                (esValida ? "VERDADERA (true)" : "FALSA (false)"));
    }

    // Carga la clave privada x desde archivo, o la genera si no existe.
    public static BigInteger obtenerClavePrivada() throws Exception {
        if (!Files.exists(Paths.get(ARCHIVO_CLAVE_PRIVADA))) {
            // x aleatorio en [1, q-1]
            BigInteger x;
            do {
                x = new BigInteger(Q.bitLength(), RND);
            } while (x.compareTo(BigInteger.ONE) < 0 || x.compareTo(Q) >= 0);
            Files.write(Paths.get(ARCHIVO_CLAVE_PRIVADA), x.toString().getBytes(StandardCharsets.UTF_8));
            System.out.println("(Se generó tu clave privada por primera vez y se guardó en archivo)");
        }
        String texto = new String(Files.readAllBytes(Paths.get(ARCHIVO_CLAVE_PRIVADA)), StandardCharsets.UTF_8);
        return new BigInteger(texto.trim());
    }

    // Deriva y guarda la clave pública y = g^x mod p.
    public static BigInteger obtenerClavePublica(BigInteger x) throws Exception {
        BigInteger y = G.modPow(x, P);
        Files.write(Paths.get(ARCHIVO_CLAVE_PUBLICA), y.toString().getBytes(StandardCharsets.UTF_8));
        return y;
    }

    
    public static BigInteger[] firmarMensaje(String mensaje, BigInteger x) throws Exception {
        // k aleatorio en [1, q-1] (debe ser distinto en cada firma)
        BigInteger k;
        do {
            k = new BigInteger(Q.bitLength(), RND);
        } while (k.compareTo(BigInteger.ONE) < 0 || k.compareTo(Q) >= 0);

        BigInteger r = G.modPow(k, P);                 // compromiso r = g^k mod p
        BigInteger e = hashModQ(mensaje, r);            // reto e = H(m || r) mod q
        BigInteger s = k.subtract(x.multiply(e)).mod(Q); // respuesta s = (k - x*e) mod q

        return new BigInteger[]{e, s};
    }

    // Verificación: reconstruye r' = g^s * y^e mod p y compara el reto.
    public static boolean verificarFirma(String mensaje, BigInteger e, BigInteger s, BigInteger y) throws Exception {
        BigInteger rPrima = G.modPow(s, P).multiply(y.modPow(e, P)).mod(P);
        BigInteger ePrima = hashModQ(mensaje, rPrima);
        return ePrima.equals(e);
    }

    // Hash "casero": SHA-256 de (mensaje || r), convertido a entero módulo q.
    private static BigInteger hashModQ(String mensaje, BigInteger r) throws Exception {

        byte[] hash = Hashing.Hash(mensaje);
        return new BigInteger(1, hash).mod(Q);
    }
}
